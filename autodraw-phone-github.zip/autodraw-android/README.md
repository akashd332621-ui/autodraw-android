# AutoDraw Mobile

Android port concept of the supplied AutoDraw desktop project.

## What it does
- Picks an image from the phone.
- Converts dark pixels into connected drawing strokes.
- Maps the image into a configurable screen rectangle.
- Uses Android AccessibilityService `dispatchGesture()` to replay strokes in the foreground app.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## Important
Android's security model does not allow a normal app to inject arbitrary touch events. The app therefore requires the user to explicitly enable its Accessibility Service. Set the drawing rectangle carefully for the target app before starting.
