package com.autodraw.mobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper

class AutoDrawAccessibilityService : AccessibilityService() {
    companion object { var instance: AutoDrawAccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    private var stopped = false

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopped = true }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun stopDrawing() { stopped = true }

    fun draw(strokes: List<List<PointF>>, duration: Long, gap: Long, onDone: () -> Unit) {
        if (strokes.isEmpty()) { onDone(); return }
        stopped = false
        drawNext(strokes, 0, duration, gap, onDone)
    }

    private fun drawNext(strokes: List<List<PointF>>, index: Int, duration: Long, gap: Long, onDone: () -> Unit) {
        if (stopped || index >= strokes.size) { onDone(); return }
        val pts = strokes[index]
        if (pts.isEmpty()) { drawNext(strokes, index + 1, duration, gap, onDone); return }
        val path = Path().apply { moveTo(pts[0].x, pts[0].y); for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration.coerceIn(20, 60000))
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { handler.postDelayed({ drawNext(strokes, index + 1, duration, gap, onDone) }, gap) }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (!stopped) handler.post { drawNext(strokes, index + 1, duration, gap, onDone) } }
        }, handler)
        if (!ok) onDone()
    }
}

data class PointF(val x: Float, val y: Float)
