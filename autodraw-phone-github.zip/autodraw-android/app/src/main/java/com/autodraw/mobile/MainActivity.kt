package com.autodraw.mobile

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var bitmap: Bitmap? = null
    private val imageReq = 42
    private lateinit var status: TextView
    private lateinit var x: EditText; private lateinit var y: EditText; private lateinit var w: EditText; private lateinit var h: EditText
    private lateinit var threshold: SeekBar
    private lateinit var duration: EditText; private lateinit var gap: EditText

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        fun text(s: String, size: Float = 16f) = TextView(this).apply { text=s; textSize=size; setPadding(0,8,0,8) }
        val title = text("AutoDraw Mobile", 24f); title.gravity = Gravity.CENTER
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val pick = Button(this).apply { text="Choose image"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, imageReq) } }
        root.addView(pick)
        status = text("No image selected")
        root.addView(status)
        root.addView(text("Drawing area on the target app (screen pixels)"))
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        x=field("X", "0"); y=field("Y", "0"); w=field("Width", "1080"); h=field("Height", "1800")
        row.addView(x, weight()); row.addView(y, weight()); row.addView(w, weight()); row.addView(h, weight()); root.addView(row)
        root.addView(text("Black threshold: 0–255")); threshold=SeekBar(this).apply { max=255; progress=127 }; root.addView(threshold)
        val timing = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        duration=field("Stroke ms", "250"); gap=field("Gap ms", "20"); timing.addView(duration, weight(2)); timing.addView(gap, weight(2)); root.addView(timing)
        val access = Button(this).apply { text="Enable Accessibility"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }; root.addView(access)
        val start = Button(this).apply { text="START DRAWING"; setOnClickListener { startDrawing() } }; root.addView(start)
        val stop = Button(this).apply { text="STOP"; setOnClickListener { AutoDrawAccessibilityService.instance?.stopDrawing(); status.text="Stopped" } }; root.addView(stop)
        root.addView(text("Tip: set the drawing rectangle to the exact canvas in the app you want to draw in, then switch back and press Start."))
        setContentView(root)
    }
    private fun field(hint: String, value: String) = EditText(this).apply { this.hint=hint; setText(value); inputType=2 }
    private fun weight(w: Int=1)=LinearLayout.LayoutParams(0,-2,w)

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==imageReq && resultCode==RESULT_OK) { data?.data?.let { bitmap=BitmapFactory.decodeStream(contentResolver.openInputStream(it)); status.text="Image: ${bitmap?.width}×${bitmap?.height}" } } }

    private fun startDrawing() {
        val src=bitmap ?: run { status.text="Choose an image first"; return }
        val service=AutoDrawAccessibilityService.instance ?: run { status.text="Enable AutoDraw Mobile in Accessibility first"; return }
        val rx=x.text.toString().toFloatOrNull()?:0f; val ry=y.text.toString().toFloatOrNull()?:0f; val rw=w.text.toString().toFloatOrNull()?:1080f; val rh=h.text.toString().toFloatOrNull()?:1800f
        val maxSide=700
        val scale=min(maxSide.toFloat()/src.width, maxSide.toFloat()/src.height).coerceAtMost(1f)
        val bmp=Bitmap.createScaledBitmap(src,max(1,(src.width*scale).roundToInt()),max(1,(src.height*scale).roundToInt()),true)
        val strokes=generateStrokes(bmp,rx,ry,rw,rh,threshold.progress)
        status.text="Generated ${strokes.size} strokes. Switch to the target app within 5 seconds…"
        val strokeMs=duration.text.toString().toLongOrNull()?:250
        val gapMs=gap.text.toString().toLongOrNull()?:20
        Handler(Looper.getMainLooper()).postDelayed({
            service.draw(strokes,strokeMs,gapMs){ runOnUiThread{status.text="Drawing finished"} }
        },5000)
    }

    private fun generateStrokes(b:Bitmap,rx:Float,ry:Float,rw:Float,rh:Float,t:Int):List<List<PointF>> {
        val sx=rw/b.width; val sy=rh/b.height; val visited=BooleanArray(b.width*b.height); val out=ArrayList<List<PointF>>()
        fun black(px:Int,py:Int)=android.graphics.Color.red(b.getPixel(px,py)) < t
        val dirs=arrayOf(intArrayOf(1,0),intArrayOf(-1,0),intArrayOf(0,1),intArrayOf(0,-1))
        for(py in 0 until b.height) for(px in 0 until b.width) {
            val idx=py*b.width+px; if(visited[idx]||!black(px,py)) continue
            val q=java.util.ArrayDeque<Int>(); val pts=ArrayList<Int>(); q.add(idx); visited[idx]=true
            while(q.isNotEmpty()) { val cur=q.removeFirst(); pts.add(cur); val cx=cur%b.width; val cy=cur/b.width
                for(d in dirs){val nx=cx+d[0];val ny=cy+d[1];if(nx in 0 until b.width&&ny in 0 until b.height){val ni=ny*b.width+nx;if(!visited[ni]&&black(nx,ny)){visited[ni]=true;q.add(ni)}}}
            }
            if(pts.size<2) continue
            val stroke=ArrayList<PointF>(pts.size); for(p in pts){val cx=p%b.width;val cy=p/b.width;stroke.add(PointF(rx+(cx+.5f)*sx,ry+(cy+.5f)*sy))}
            out.add(stroke)
        }
        return out
    }
}
