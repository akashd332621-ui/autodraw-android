# AutoDraw — Phone-only APK build

You can build this Android app entirely from your phone using GitHub Actions.

## 1. Create a GitHub repository

Create a new repository on GitHub and upload **all files in this folder**.

Keep the `.github/workflows/build-apk.yml` file in exactly that location.

## 2. Build from your phone

1. Open the repository on GitHub.
2. Open **Actions**.
3. Select **Build AutoDraw APK**.
4. Tap **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run.
7. Under **Artifacts**, download `AutoDraw-debug-apk`.
8. Extract the downloaded artifact and install the APK on your Android phone.

## 3. If GitHub doesn't show "Run workflow"

Push/commit the files to the `main` branch first. Then refresh the Actions page.

## Notes

This produces a debug APK. Android may show a warning when installing an APK downloaded outside Google Play; only install builds from your own repository.
